package model;

import java.util.Date;

import com.ibm.icu.text.SimpleDateFormat;

/**
 * Classe inscription
 * Projet PDL Groupe 2_1 bin�me 3 LADIBE Samuel && ELEGBEDE Divine
 *
 *  @author Ladib� Samuel
 *  @version 1.0
 */
public class inscription {
	int id;
	private String inscriptionNom;
	private String inscriptionPrenom;
	private Date datenaiss;
	private String adresse;
	private String adresseMail;
	private String raison;
	private String sex;
	
	
	public inscription(int id, String inscriptionNom, String inscriptionPrenom, Date datenaiss, String adresse,
			String adresseMail, String raison, String sex) {
		super();
		this.id = id;
		this.inscriptionNom = inscriptionNom;
		this.inscriptionPrenom = inscriptionPrenom;
		this.datenaiss = datenaiss;
		this.adresse = adresse;
		this.adresseMail = adresseMail;
		this.raison = raison;
		this.sex = sex;
	}
	
	/**
	 * getter de l'attribut id
	 * @return
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * setter de l'attribut id
	 * @param id
	 */
	public void setId(int id) {
		this.id=id;
	}
	
	/**
	 * Getter de l'attribut datenaiss
	 * @return
	 */
	public Date getDateNaiss() {
		return datenaiss;
	}
	
	/**
	 * setter de l'attribut datenaiss
	 * @param datenaiss
	 */
	public void setDateNaiss(Date datenaiss) {
		this.datenaiss = datenaiss;
	}
	/**
	 * getter de l'attribut adresse
	 * @return
	 */
	public String getAdresse() {
		return adresse;
	}

	/**
	 * setter de l'attribut adresse
	 * @param adresse
	 */
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	
	/**
	 * getter de l'attribut adresseMail
	 * @return the adressMail
	 */
	public String getAdresseMail() {
		return adresseMail;
	}
	
	/**
	 * getter de l'attribut inscriptionNom
	 * @return the inscriptionNom
	 */
	public String getInscriptionNom() {
		return inscriptionNom;
	}
	
	/**
	 * getter de l'attribut inscriptionPrenom
	 * @return the inscriptionPrenom
	 */
	public String getInscriptionPrenom() {
		return inscriptionPrenom;
	}
	
	/**
	 * getter de l'attribut raison
	 * @return the raison
	 */
	public String getRaison() {
		return raison;
	}
	
	/**
	 * setter de l'attribut adresseMail
	 * @param the adresseMail
	 */
	public void setAdresseMail(String adresseMail) {
		this.adresseMail = adresseMail;
	}
	
	/**
	 * setter de l'attirbut inscriptionNom
	 * @param the inscriptionNom
	 */
	public void setInscriptionNom(String inscriptionNom) {
		this.inscriptionNom = inscriptionNom;
	}
	
	/**
	 * setter de l'attribut inscriptionPrenom
	 * @param the inscriptionPrenom
	 */
	public void setInscriptionPrenom(String inscriptionPrenom) {
		this.inscriptionPrenom = inscriptionPrenom;
	}
	
	/**
	 * setter de l'attribut raison
	 * @param the raison
	 */
	public void setRaison(String raison) {
		this.raison = raison;
	}
	
	/**
	 * getter de l'attribut sex
	 * @return
	 */
	public String getSex() {
		return sex;
	}
	
	/**
	 * setter de l'attribut sex
	 * @param sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	public void validerInscription() {
		System.out.println("Inscription valid�e");
	}
	
	/**
	 * m�thode refsuerInscription
	 * affiche inscription refus�e
	 */
	public void refuserInscription() {
		System.out.println("Inscription refus�e");
	}
	
	/**
	 * m�thode display
	 * affiche les informations d'une inscription
	 */
	public void display() {
		System.out.println("Adresse e-mail :" + adresseMail);
		System.out.println("Nom :" + inscriptionNom);
		System.out.println("Prenom :" + inscriptionPrenom);
		System.out.println("Raison :" + raison);
		System.out.println("Date de naissance :" +datenaiss);
		System.out.println("Adresse :" + adresse);
		System.out.println("Sex :" + sex);
	}
	
}

