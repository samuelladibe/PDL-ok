package model;

public class Vehicule {
	private String model;
	private String marque;
	private float longueur;
	private float largeur;
	
	/**
	 * Constructeur de la classe Vehicule
	 * @param model
	 * @param marque
	 * @param longueur
	 * @param largeur
	 */
	public Vehicule(String model, String marque, float longueur, float largeur) {
		super();
		this.model = model;
		this.marque = marque;
		this.longueur = longueur;
		this.largeur = largeur;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the marque
	 */
	public String getMarque() {
		return marque;
	}

	/**
	 * @param marque the marque to set
	 */
	public void setMarque(String marque) {
		this.marque = marque;
	}

	/**
	 * @return the longueur
	 */
	public float getLongueur() {
		return longueur;
	}

	/**
	 * @param longueur the longueur to set
	 */
	public void setLongueur(float longueur) {
		this.longueur = longueur;
	}

	/**
	 * @return the largeur
	 */
	public float getLargeur() {
		return largeur;
	}

	/**
	 * @param largeur the largeur to set
	 */
	public void setLargeur(float largeur) {
		this.largeur = largeur;
	}
	
	public void display() {
		System.out.println("Mod�le : " + model);
		System.out.println("Marque : " + marque);
		System.out.println("Longueur : " + longueur);
		System.out.println("Largeur : " + largeur);
	}

}
