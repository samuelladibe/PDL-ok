package model;

import java.util.ArrayList;

public class Organisateur {
	private String nomOrganisateur;
	private String prenomOrganisateur;
	private String idOrganisateur;
	private ArrayList<inscription> listDinscription; 
	
	/**
	 * Constructeur de la classe organisateur
	 * @param nomOrga
	 * @param prenomOrga
	 * @param idOrga
	 */
	public Organisateur(String nomOrga, String prenomOrga, String idOrga) {
		this.idOrganisateur= idOrga;
		this.nomOrganisateur = nomOrga;
		this.prenomOrganisateur = prenomOrga;
		this.listDinscription = new ArrayList<inscription>();
	}
	/**
	 * getter de l'attribut nomOrganisateur
	 * @return nomOrganisateur
	 */
	public String getNomOrganisateur() {
		return nomOrganisateur;
	}
	/**
	 * getter de l'attribut prenomOrganisateur
	 * @return prenomOrganisateur
	 */
	public String getPrenomOrganisateur() {
		return prenomOrganisateur;
	}
	
	/**
	 * getter de l'attribut idOrganisateur
	 * @return diOrganisateur
	 */
	public String getIdOrganisateur() {
		return idOrganisateur;
	}
	
	/**
	 * m�thode addInscription 
	 * @param uneInscription
	 */
	public void addInscription(inscription uneInscription) {
		this.listDinscription.add(uneInscription);
	}
	
	/**
	 * m�thode addParticipant
	 * @param unParticipant
	 */
	
	/**
	 * setter de l'attribut nomOrganisateur
	 * @param nomOrga
	 */
	public void setNomOrganisateur(String nomOrga) {
		this.nomOrganisateur = nomOrga;
	}
	
	/**
	 * setter de l'attribut prenomOrganisateur
	 * @param prenomOrga
	 */
	public void setPrenomOrganisateur(String prenomOrga) {
		this.prenomOrganisateur = prenomOrga;
	}
	
	/**
	 * setter de l'attribut idOrganisateur
	 * @param idOrga
	 */
	public void setIdOrganisateur(String idOrga) {
		this.idOrganisateur = idOrga;
	}

}
