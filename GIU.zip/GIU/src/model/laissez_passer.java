package model;

/**
 * @author Ladib� Samuel
 * Projet PDL Groupe 2_1 bin�me 3 LADIBE Samuel && ELEGBEDE Divine
 * Classe laissez-passer
 */

public class laissez_passer {
	private String nom;
	private String prenom;
	private Vehicule vehicule;
	private boolean estImprime;
	private boolean estArchive;
	private boolean estDemande;
	private boolean estValide;
	
	/**
	 * Constructeur de la classe 
	 * @param nom
	 * @param prenom
	 * @param vehicule
	 * @param estImprime
	 * @param estArchive
	 * @param estDemande
	 * @param estValide
	 */
	public laissez_passer(String nom, String prenom, Vehicule vehicule, boolean estImprime, boolean estArchive,
			boolean estDemande, boolean estValide) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.vehicule = vehicule;
		this.estImprime = estImprime;
		this.estArchive = estArchive;
		this.estDemande = estDemande;
		this.estValide = estValide;
	}



	/**
	 * Getter de l'attirbut nom
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}



	/**
	 * Setter de l'attribut nom
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}



	/**
	 * Getter de l'attirbut prenom
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}



	/**Setter de l'attribut prenom
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}



	/**
	 * Getter de l'attirbut vehicule
	 * @return the vehicule
	 */
	public Vehicule getVehicule() {
		return vehicule;
	}



	/**
	 * Setter de l'attribut vehicule
	 * @param vehicule the vehicule to set
	 */
	public void setVehicule(Vehicule vehicule) {
		this.vehicule = vehicule;
	}



	/**
	 * Getter de l'attirbut estImprime
	 * @return the estImprime
	 */
	public boolean estImprime() {
		return estImprime;
	}



	/**
	 * Setter de l'attribut estImprime
	 * @param estImprime the estImprime to set
	 */
	public void setEstImprime(boolean estImprime) {
		this.estImprime = estImprime;
	}



	/**
	 * Getter de l'attirbut estarchive
	 * @return the estArchive
	 */
	public boolean estArchive() {
		return estArchive;
	}



	/**
	 * Setter de l'attribut estArchive
	 * @param estArchive the estArchive to set
	 */
	public void setEstArchive(boolean estArchive) {
		this.estArchive = estArchive;
	}



	/**
	 * Getter de l'attirbut estDemande
	 * @return the estDemande
	 */
	public boolean estDemande() {
		return estDemande;
	}



	/**
	 * Setter de l'attribut estDemande
	 * @param estDemande the estDemande to set
	 */
	public void setEstDemande(boolean estDemande) {
		this.estDemande = estDemande;
	}



	/**Getter de l'attirbut est valide
	 * @return the estValide
	 */
	public boolean estValide() {
		return estValide;
	}



	/**
	 * Setter de l'attribut estValide
	 * @param estValide the estValide to set
	 */
	public void setEstValide(boolean estValide) {
		this.estValide = estValide;
	}



	public void display() {
		System.out.println("Nom : " + nom);
		System.out.println("Pr�nom : " + prenom);
		System.out.println("Laissez-passer demand� : " + estDemande);
		System.out.println("Laissez-passer imprim�s : " + estImprime);
		System.out.println("Laissez-passer archiv� : " + estArchive);
		System.out.println("Laissez-passer valide : " + estValide);
		
		
	}
	
}
