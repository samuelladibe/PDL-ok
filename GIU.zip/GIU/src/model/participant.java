package model;

import java.util.ArrayList;
/**
 * 
 */

/**
 * @author Ladib� Samuel
 * Projet PDL Groupe 2_1 bin�me 3 LADIBE Samuel && ELEGBEDE Divine
 * Classe participant
 */

public class participant {
	protected String profil ;
	protected String matricule ;
	protected boolean VIP ;
	private ArrayList<laissez_passer> listLaissezPasser;
	
	/**
	 * Constructeur de la classe participant
	 * @param profil
	 * @param matricule
	 * @param vIP
	 */
	public participant(String profil, String matricule, boolean vIP) {
		super();
		this.profil = profil;
		this.matricule = matricule;
		VIP = vIP;
		this.listLaissezPasser = new ArrayList<laissez_passer>();
	}


	/**
	 * @return the profil
	 */
	public String getProfil() {
		return profil;
	}


	/**
	 * @param profil the profil to set
	 */
	public void setProfil(String profil) {
		this.profil = profil;
	}


	/**
	 * @return the matricule
	 */
	public String getMatricule() {
		return matricule;
	}


	/**
	 * @param matricule the matricule to set
	 */
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}


	/**
	 * @return the vIP
	 */
	public boolean isVIP() {
		return VIP;
	}


	/**
	 * @param vIP the vIP to set
	 */ 
	public void setVIP(boolean vIP) {
		VIP = vIP;
	}
	
	/**
	 * m�thode addLaissez_passer ajoute un laissez_passer � la liste listLaissezPasser
	 * @param unLaisserPasser
	 */
	public void addLaissez_passer(laissez_passer unLaisserPasser) {
		this.listLaissezPasser.add(unLaisserPasser);
	}

	/**
	 * m�thode display
	 * affiche les caract�ristiques d'un participant
	 */
	public void display() {
		System.out.println("Profil :" + profil);
		System.out.println("Matricule :" + matricule);
		System.out.println("VIP :" + VIP) ;
		
	}
}
