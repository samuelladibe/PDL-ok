package model;

public class Compte {
	private int idCompte;
	private String identifiant;
	private String mdp;
	
	/**
	 * Constructeur de la classe Compte
	 * @param idCompte
	 * @param identifiant
	 * @param mdp
	 */
	public Compte(int idCompte, String identiant, String mdp) {
		super();
		this.idCompte = idCompte;
		this.identifiant = identiant;
		this.mdp = mdp;
	}

	/**
	 * @return the idCompte
	 */
	public int getIdCompte() {
		return idCompte;
	}

	/**
	 * @param idCompte the idCompte to set
	 */
	public void setIdCompte(int idCompte) {
		this.idCompte = idCompte;
	}

	/**
	 * @return the identifiant
	 */
	public String getIdentifiant() {
		return identifiant;
	}

	/**
	 * @param identiant the identifiant to set
	 */
	public void setIdentiant(String identiant) {
		this.identifiant = identiant;
	}

	/**
	 * @return the mdp
	 */
	public String getMdp() {
		return mdp;
	}

	/**
	 * @param mdp the mdp to set
	 */
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

}
