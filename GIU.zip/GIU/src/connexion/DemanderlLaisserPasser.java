package connexion;

import java.awt.EventQueue;
import java.util.*;
import java.util.function.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DemanderlLaisserPasser {

	public JFrame frmDlaissezpasser;
	private JTextField nom;
	private JTextField prenom;
	private JTextField modele;
	private JTextField marque;
	private JTextField longueur;
	private JTextField largeur;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DemanderlLaisserPasser window = new DemanderlLaisserPasser();
					window.frmDlaissezpasser.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DemanderlLaisserPasser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmDlaissezpasser = new JFrame();
		frmDlaissezpasser.getContentPane().setBackground(new Color(135, 206, 250));
		frmDlaissezpasser.setTitle("Dlaissezpasser");
		frmDlaissezpasser.setBounds(100, 100, 665, 488);
		frmDlaissezpasser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDlaissezpasser.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\wadjo\\Desktop\\Esigelec 1A\\PDL\\LOT 3\\logo.png"));
		lblNewLabel.setBounds(10, 109, 212, 181);
		frmDlaissezpasser.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("LAISSEZ-PASSER");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(54, 62, 159, 36);
		frmDlaissezpasser.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_3 = new JButton("Retour");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				laisser_passer l = new laisser_passer();
				l.frame.setVisible(true);
				frmDlaissezpasser.dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(82, 402, 86, 23);
		frmDlaissezpasser.getContentPane().add(btnNewButton_3);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(245, 11, 396, 429);
		frmDlaissezpasser.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Nom");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(10, 50, 49, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Pr\u00E9nom");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2_1.setBounds(10, 88, 71, 14);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Mod\u00E8le");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2_1_1.setBounds(10, 165, 71, 14);
		panel.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Marque");
		lblNewLabel_2_1_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2_1_2.setBounds(10, 204, 71, 18);
		panel.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_2_1_3 = new JLabel("Longueur");
		lblNewLabel_2_1_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2_1_3.setBounds(10, 246, 71, 18);
		panel.add(lblNewLabel_2_1_3);
		
		JLabel lblNewLabel_2_1_4 = new JLabel("Largeur");
		lblNewLabel_2_1_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2_1_4.setBounds(10, 287, 71, 18);
		panel.add(lblNewLabel_2_1_4);
		
		JLabel lblNewLabel_2_1_5 = new JLabel("Informations personelles");
		lblNewLabel_2_1_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2_1_5.setBounds(10, 11, 190, 14);
		panel.add(lblNewLabel_2_1_5);
		
		JButton btnNewButton_1 = new JButton("Soumettre la demande");
		btnNewButton_1.setBounds(154, 347, 190, 23);
		panel.add(btnNewButton_1);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBackground(new Color(205, 92, 92));
		
		JLabel lblNewLabel_2_1_5_1 = new JLabel("Informations sur le Vehicule");
		lblNewLabel_2_1_5_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2_1_5_1.setBounds(10, 126, 235, 14);
		panel.add(lblNewLabel_2_1_5_1);
		
		nom = new JTextField();
		nom.setEditable(false);
		nom.setBounds(69, 48, 269, 20);
		panel.add(nom);
		nom.setColumns(10);
		
		prenom = new JTextField();
		prenom.setEditable(false);
		prenom.setColumns(10);
		prenom.setBounds(69, 86, 269, 20);
		panel.add(prenom);
		
		modele = new JTextField();
		modele.setColumns(10);
		modele.setBounds(69, 165, 269, 18);
		panel.add(modele);
		
		marque = new JTextField();
		marque.setColumns(10);
		marque.setBounds(69, 204, 269, 20);
		panel.add(marque);
		
		longueur = new JTextField();
		longueur.setColumns(10);
		longueur.setBounds(69, 244, 269, 20);
		panel.add(longueur);
		
		largeur = new JTextField();
		largeur.setColumns(10);
		largeur.setBounds(69, 287, 269, 20);
		panel.add(largeur);
		
			public void printComponent() {

				  PrinterJob pj = PrinterJob.getPrinterJob();
				  pj.setJobName(" Print Component ");

				  pj.setPrintable (new Printable() {    
				    public int print(Graphics pg, PageFormat pf, int pageNum) {
				      if (pageNum > 0) return Printable.NO_SUCH_PAGE;

				      Graphics2D g2 = (Graphics2D) pg;
				      g2.translate(pf.getImageableX(), pf.getImageableY());
				      componenet_name.paint(g2);
				      return Printable.PAGE_EXISTS;
				    }
				  });

				  if (pj.printDialog() == false) return;

				  try {
				    pj.print();
				  } catch (PrinterException ex) {
				    // handle exception
				  }
			}
		
		JButton btnNewButton_1_1 = new JButton("Imprimer");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showConfirmDialog(btnNewButton_1_1, "Vouslez-vous imprimer ?");
				printComponent();
			}
			
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1_1.setBackground(new Color(205, 92, 92));
		btnNewButton_1_1.setBounds(154, 381, 190, 23);
		panel.add(btnNewButton_1_1);
	}
}
