package connexion;

import java.util.*;
import java.util.regex.Pattern;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.tree.DefaultTreeModel;

import dao.CompteDAO;
import dao.InscriptionDAO;
import model.Compte;
import model.inscription;
import model.Compte;

import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.demo.DateChooserPanel;
import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.toedter.calendar.JCalendar;

public class Inscription {

	public JFrame frmInscription;
	private JTextField textFieldNOM;
	private JTextField textFieldPRENOM;
	private JTextField textFieldRAISON;
	private JTextField textFieldADRESSEMAIL;

	private boolean newInscription = false ;
	private boolean newCompte = false ;
	private JTextField adresse;
	private JTextField datenaiss;
	private JTextField creermdp;
	private JTextField confirmmdp;
	String choix;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inscription window = new Inscription();
					window.frmInscription.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inscription() {
		initialize();
	}

	/**
	 * m�thode permettant de verifier si un champ est vide
	 * @param field
	 * @return
	 */
	private boolean checkField(String field){
		if(!field.isEmpty()){ 
			return false;
		}else{
			return true;
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInscription = new JFrame();
		frmInscription.getContentPane().setBackground(new Color(105, 105, 105));
		frmInscription.setResizable(false);
		frmInscription.setTitle("Inscription");
		frmInscription.setBounds(100, 100, 831, 510);
		frmInscription.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInscription.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(135, 206, 250));
		panel.setBounds(10, 11, 457, 451);
		frmInscription.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("INSCRIPTION");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(147, 27, 130, 14);
		panel.add(lblNewLabel);

		JLabel lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNom.setBounds(48, 61, 51, 24);
		panel.add(lblNom);

		textFieldNOM = new JTextField();
		textFieldNOM.setBounds(48, 89, 378, 24);
		panel.add(textFieldNOM);
		textFieldNOM.setColumns(10);

		JLabel lblPrenom = new JLabel("Prenom");
		lblPrenom.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPrenom.setBounds(48, 113, 51, 24);
		panel.add(lblPrenom);

		textFieldPRENOM = new JTextField();
		textFieldPRENOM.setColumns(10);
		textFieldPRENOM.setBounds(48, 148, 378, 24);
		panel.add(textFieldPRENOM);

		JLabel lblNom_1_1 = new JLabel("Date de naissance");
		lblNom_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNom_1_1.setBounds(48, 183, 113, 24);
		panel.add(lblNom_1_1);

		JLabel lblRaisonSociale = new JLabel("Raison");
		lblRaisonSociale.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRaisonSociale.setBounds(48, 323, 87, 24);
		panel.add(lblRaisonSociale);

		textFieldRAISON = new JTextField();
		textFieldRAISON.setColumns(10);
		textFieldRAISON.setBounds(48, 358, 378, 24);
		panel.add(textFieldRAISON);

		JButton btnEnregistrer = new JButton("Enregistrer");
		btnEnregistrer.setBackground(new Color(205, 92, 92));
		btnEnregistrer.setBounds(294, 405, 121, 23);
		panel.add(btnEnregistrer);

		JLabel lblAdresse = new JLabel("Adresse");
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAdresse.setBounds(48, 253, 87, 24);
		panel.add(lblAdresse);

		adresse = new JTextField();
		adresse.setColumns(10);
		adresse.setBounds(48, 288, 209, 24);
		panel.add(adresse);

		JLabel lblSexe = new JLabel("Sexe");
		lblSexe.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSexe.setBounds(285, 253, 51, 24);
		panel.add(lblSexe);

		JComboBox sex = new JComboBox();
		sex.setModel(new DefaultComboBoxModel(new String[] {"M", "F", "Ne pas se d\u00E9cider"}));
		sex.setBounds(267, 287, 141, 26);
		panel.add(sex);
		sex.setSelectedItem("M");
		sex.addActionListener(new ActionListener() {     
			@Override
			public void actionPerformed(ActionEvent e) {
				choix = sex.getSelectedItem().toString();      
			}
		});

		datenaiss = new JTextField();
		datenaiss.setBackground(new Color(240, 255, 255));
		datenaiss.setText("Astuce : Choisir d'abord l'ann\u00E9e ensuite, le mois et enfin le jour. ");
		datenaiss.setEditable(false);
		datenaiss.setColumns(10);
		datenaiss.setBounds(48, 218, 378, 24);
		panel.add(datenaiss);

		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(188, 183, 130, 24);
		panel.add(dateChooser);

		btnEnregistrer.addActionListener(new ActionListener() {
			@SuppressWarnings("unlikely-arg-type")
			public void actionPerformed(ActionEvent e) {
				try {
					if(checkField(textFieldNOM.getText())==false ||
							checkField(textFieldPRENOM.getText()) == false ||
							checkField(textFieldADRESSEMAIL.getText())==false ||
							checkField(textFieldRAISON.getText())== false ||
							dateChooser.getDate() == null || checkField(choix) == false ||
							checkField(adresse.getText()) == false ||
							checkField(creermdp.getText())==false || 
							checkField(confirmmdp.getText())==false) { 	// on v�irifie que le champ entr� par l'utilisateur n'est pas vide
						if(!Pattern.matches("^[a-zA-Z0-9]+[@]{1}+[a-zA-Z0-9]+[.]{1}+[a-zA-Z0-9]+$", textFieldADRESSEMAIL.getText())) {
							JOptionPane.showMessageDialog(null, "E-mail invalide");
						}else {
							if(new InscriptionDAO().Verifier(textFieldADRESSEMAIL.getText())==null
									) { // on v�rifie que l'adressemail entr�e par l'utilisateur n'est pas d�j� utilis�e
								SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyy");
								String convertedDate = df.format(dateChooser.getDate());
								datenaiss.setText(convertedDate);
								new InscriptionDAO().addInscription(new inscription(0,
										textFieldNOM.getText(),
										textFieldPRENOM.getText(),
										dateChooser.getDate(),
										adresse.getText(),
										textFieldADRESSEMAIL.getText(),
										textFieldRAISON.getText(),
										choix));
								JOptionPane.showMessageDialog(null, "Inscription enregistr�e");
								textFieldNOM.setEditable(false);
								textFieldPRENOM.setEditable(false);
								textFieldRAISON.setEditable(false);
								adresse.setEditable(false);
								datenaiss.setEditable(false);
								dateChooser.setEnabled(false);
								sex.setEnabled(false);
								btnEnregistrer.setEnabled(false);
								newInscription = false;
							}
							else {
								if(textFieldNOM.getText().equals(new InscriptionDAO().Verifier(textFieldADRESSEMAIL.getText()).getInscriptionNom())
										&& textFieldPRENOM.getText().equals(new InscriptionDAO().Verifier(textFieldADRESSEMAIL.getText()).getInscriptionPrenom())
										&& adresse.getText().equals(new InscriptionDAO().Verifier(textFieldADRESSEMAIL.getText()).getAdresse())) {
									JOptionPane.showMessageDialog(null, "Participant d�j� isnicrit car e-mail, nom, prenom et adresse utilis�s");
								}
							}
						}
					}

				}
				catch(Exception e1) {
					JOptionPane.showInternalMessageDialog(null, "Les champs sont vides");
					textFieldNOM.setText("");
					textFieldPRENOM.setText("");
					textFieldRAISON.setText("");
					adresse.setText("");
				}
			}
		});

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(463, 11, 344, 451);
		frmInscription.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		JLabel lblCreerUnCompte = new JLabel("CREER UN COMPTE");
		lblCreerUnCompte.setForeground(new Color(0, 0, 0));
		lblCreerUnCompte.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCreerUnCompte.setBounds(108, 28, 157, 14);
		panel_1.add(lblCreerUnCompte);

		JLabel lblNom_1 = new JLabel("Adressse e-mail");
		lblNom_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNom_1.setBounds(29, 53, 130, 24);
		panel_1.add(lblNom_1);

		JLabel lblNom_2 = new JLabel("Cr\u00E9er un mot de passe");
		lblNom_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNom_2.setBounds(29, 123, 178, 24);
		panel_1.add(lblNom_2);

		JLabel lblNom_3 = new JLabel("Confirmer le mot de passe");
		lblNom_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNom_3.setBounds(29, 193, 178, 24);
		panel_1.add(lblNom_3);

		textFieldADRESSEMAIL = new JTextField();
		textFieldADRESSEMAIL.setColumns(10);
		textFieldADRESSEMAIL.setBounds(29, 88, 284, 24);
		panel_1.add(textFieldADRESSEMAIL);

		JButton btnConfirmer = new JButton("Confirmer");
		btnConfirmer.setBackground(new Color(205, 92, 92));
		btnConfirmer.setBounds(122, 345, 111, 23);
		panel_1.add(btnConfirmer);

		JCheckBox chckbxNewCheckBox = new JCheckBox("Se souvenir de moi");
		chckbxNewCheckBox.setBounds(29, 284, 150, 23);
		panel_1.add(chckbxNewCheckBox);

		creermdp = new JTextField();
		creermdp.setColumns(10);
		creermdp.setBounds(29, 158, 284, 24);
		panel_1.add(creermdp);

		confirmmdp = new JTextField();
		confirmmdp.setColumns(10);
		confirmmdp.setBounds(29, 228, 284, 24);
		panel_1.add(confirmmdp);

		JButton btnRetourLa = new JButton("Retour \u00E0 la page de connexion");
		btnRetourLa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connexion p = new Connexion();
				p.frmArmada.setVisible(true);
				frmInscription.dispose();
			}
		});
		btnRetourLa.setBackground(new Color(205, 92, 92));
		btnRetourLa.setBounds(68, 379, 234, 23);
		panel_1.add(btnRetourLa);

		JLabel errormdp = new JLabel("Mots de passe diff\u00E9rents !");
		errormdp.setFont(new Font("Tahoma", Font.ITALIC, 11));
		errormdp.setForeground(new Color(255, 0, 0));
		errormdp.setBounds(29, 263, 271, 14);
		panel_1.add(errormdp);
		errormdp.setVisible(false);

		btnConfirmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!Pattern.matches("^[a-zA-Z0-9]+[@]{1}+[a-zA-Z0-9]+[.]{1}+[a-zA-Z0-9]+$", textFieldADRESSEMAIL.getText())) {
					JOptionPane.showMessageDialog(null, "E-mail invalide");
				}
				else {
					if(new InscriptionDAO().Verifier(textFieldADRESSEMAIL.getText())==null) {
						if(checkField(creermdp.getText())==false && checkField(confirmmdp.getText())==false) {
							if(creermdp.getText().equals(confirmmdp.getText())) {
								new CompteDAO().addCompte(new Compte(0, textFieldADRESSEMAIL.getText(), confirmmdp.getText()));
								JOptionPane.showMessageDialog(null, "Compte cr�e avec succ�s");
								textFieldADRESSEMAIL.setEnabled(false);;
								creermdp.setEnabled(false);
								confirmmdp.setEnabled(false);
								errormdp.setVisible(false);
								chckbxNewCheckBox.setEnabled(false);
								btnConfirmer.setEnabled(false);
							}
							else {
								errormdp.setVisible(true);
								textFieldADRESSEMAIL.setEnabled(true);;
								creermdp.setText("");
								confirmmdp.setText("");
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Entrez un mot de passe");
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Email d�j� utilis�");
					}
				}
			}
		});
	}
}
