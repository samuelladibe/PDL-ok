package connexion;

import java.awt.EventQueue;
import dao.CompteDAO;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Connexion {

	public JFrame frmArmada;
	private JTextField identifiant;
	private JTextField mdp;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Connexion window = new Connexion();
					window.frmArmada.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Connexion() {
		initialize();
	}
	
	/**
	 * m�thode permettant de verifier si un champ est vide
	 * @param field
	 * @return
	 */
	private boolean checkField(String field){
		if(!field.isEmpty()){ 
			return false;
		}else{
			return true;
		}
	 }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmArmada = new JFrame();
		frmArmada.setResizable(false);
		frmArmada.getContentPane().setFont(new Font("Georgia", Font.PLAIN, 12));
		frmArmada.setTitle("Armada 2023");
		frmArmada.setBounds(100, 100, 707, 472);
		frmArmada.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmArmada.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setToolTipText("");
		panel.setForeground(new Color(105, 105, 105));
		frmArmada.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.WHITE);
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setHgap(50);
		flowLayout.setAlignOnBaseline(true);
		flowLayout.setAlignment(FlowLayout.RIGHT);
		panel.add(panel_1, BorderLayout.WEST);
		
		JLabel lblNewLabel = new JLabel("BIENVENUE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setLabelFor(frmArmada);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel);
		
		Panel panel_2 = new Panel();
		panel_2.setBackground(new Color(192, 192, 192));
		panel.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(135, 206, 250));
		panel_4.setBounds(27, 26, 446, 376);
		panel_2.add(panel_4);
		panel_4.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(37, 37, 377, 273);
		panel_4.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Identifiant ou nom d'utilisateur");
		lblNewLabel_1.setBounds(43, 33, 219, 17);
		panel_3.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		identifiant = new JTextField();
		identifiant.setBounds(43, 61, 297, 30);
		panel_3.add(identifiant);
		identifiant.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Mot de passe");
		lblNewLabel_1_1.setBounds(43, 102, 138, 14);
		panel_3.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		mdp = new JTextField();
		mdp.setBounds(43, 127, 297, 30);
		panel_3.add(mdp);
		mdp.setColumns(10);
		
		JLabel lblNewLabel_3_1 = new JLabel("Vous-avez d\u00E9j\u00E0 un compte ? --->");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_1.setBounds(10, 234, 224, 14);
		panel_3.add(lblNewLabel_3_1);
		
		JButton btnNewButton = new JButton("Mot de passe oubli\u00E9 ???");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Mdpoublie m = new Mdpoublie();
				m.frmRestaurerMdp.setVisible(true);
				frmArmada.dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 10));
		btnNewButton.setBounds(202, 174, 138, 17);
		panel_3.add(btnNewButton);
		
		JButton bienvenue = new JButton("Login");
		bienvenue.setBounds(251, 231, 89, 23);
		panel_3.add(bienvenue);
		bienvenue.addActionListener(new ActionListener() {
			@SuppressWarnings("unlikely-arg-type")
			public void actionPerformed(ActionEvent e) {
				try {
					if(checkField(identifiant.getText()) == false || checkField(mdp.getText())==false) // on v�rifie si les champs sont vides
						{
						if(identifiant.getText().equals(new CompteDAO().getIdentifiantBD(identifiant.getText()).getIdentifiant()) && 
								mdp.getText().equals(new CompteDAO().getMdpBD(mdp.getText()).getMdp()))  // on v�rifie si l'identifiant et le mot de passe corespondent � ceux de la BDD
							{
								accueil f= new accueil();
								f.frmAccueil.setVisible(true);
								frmArmada.dispose();
							}
						}
					else {
						JOptionPane.showMessageDialog(null, "Entez vos identifiants");
					}
					}
					catch(Exception e1) {
						JOptionPane.showMessageDialog(null, "Identifiants incorrects");

					}
				}
			});
		bienvenue.setBackground(new Color(205, 92, 92));
		bienvenue.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JButton btnInscription = new JButton("Inscription");
		btnInscription.setBounds(281, 321, 100, 23);
		panel_4.add(btnInscription);
		btnInscription.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inscription i = new Inscription();
				i.frmInscription.setVisible(true);
				frmArmada.dispose();
			}
		});
		btnInscription.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnInscription.setBackground(new Color(205, 92, 92));
		
		JLabel lblNewLabel_3 = new JLabel("Nouveau membre ? Inscription --->");
		lblNewLabel_3.setBounds(47, 324, 224, 14);
		panel_4.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
	}
}
