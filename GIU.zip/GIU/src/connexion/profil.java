package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Scrollbar;
import javax.swing.JRadioButtonMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class profil {

	public JFrame frmProfil;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					profil window = new profil();
					window.frmProfil.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public profil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProfil = new JFrame();
		frmProfil.setTitle("Profil");
		frmProfil.setBounds(100, 100, 615, 470);
		frmProfil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProfil.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\wadjo\\Desktop\\Esigelec 1A\\PDL\\LOT 3\\logo.png"));
		lblNewLabel.setBounds(31, 11, 212, 181);
		frmProfil.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PROFIL");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(260, 188, 159, 36);
		frmProfil.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Consulter profil");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consulter_profil p = new consulter_profil();
				p.frmConsulterProfil.setVisible(true);
				frmProfil.dispose();
			}
		});
		btnNewButton.setBackground(new Color(188, 143, 143));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(85, 324, 132, 48);
		frmProfil.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Modifier profil");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifier_profil p = new modifier_profil();
				p.frmModifierProfil.setVisible(true);
				frmProfil.dispose();;
			}
		});
		btnNewButton_1.setBackground(new Color(188, 143, 143));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(348, 324, 132, 48);
		frmProfil.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("Retour");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accueil p = new accueil();
				p.frmAccueil.setVisible(true);
				frmProfil.dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setBounds(439, 47, 86, 23);
		frmProfil.getContentPane().add(btnNewButton_3);
	}
}
