package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class laisser_passer {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					laisser_passer window = new laisser_passer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public laisser_passer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(135, 206, 250));
		frame.setBounds(100, 100, 534, 318);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnDemanderUnLaissezpasser = new JButton("Demander un laissez-passer");
		btnDemanderUnLaissezpasser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DemanderlLaisserPasser p = new DemanderlLaisserPasser();
				p.frmDlaissezpasser.setVisible(true);
				frame.dispose();
			}
		});
		btnDemanderUnLaissezpasser.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDemanderUnLaissezpasser.setBackground(new Color(205, 92, 92));
		btnDemanderUnLaissezpasser.setBounds(274, 92, 209, 48);
		frame.getContentPane().add(btnDemanderUnLaissezpasser);
		
		JButton btnNewButton_1 = new JButton("Modifier la demande");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBackground(new Color(205, 92, 92));
		btnNewButton_1.setBounds(274, 178, 209, 48);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("LAISSEZ-PASSER");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(46, 26, 159, 36);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\wadjo\\Desktop\\Esigelec 1A\\PDL\\LOT 3\\logo.png"));
		lblNewLabel.setBounds(10, 76, 212, 181);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_3 = new JButton("Retour");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accueil p = new accueil();
				p.frmAccueil.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setBounds(399, 26, 86, 23);
		frame.getContentPane().add(btnNewButton_3);
	}

}
