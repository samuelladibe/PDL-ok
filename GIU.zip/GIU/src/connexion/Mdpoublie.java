package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import dao.CompteDAO;
import model.Compte;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;

public class Mdpoublie {

	public JFrame frmRestaurerMdp;
	private JTextField mail;
	private JTextField nouveaumdp;
	private JTextField cnmdp;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mdpoublie window = new Mdpoublie();
					window.frmRestaurerMdp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Mdpoublie() {
		initialize();
	}


	/**
	 * m�thode permettant de verifier si un champ est vide
	 * @param field
	 * @return
	 */
	private boolean checkField(String field){
		if(!field.isEmpty()){ 
			return false;
		}else{
			return true;
		}
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmRestaurerMdp = new JFrame();
		frmRestaurerMdp.setResizable(false);
		frmRestaurerMdp.setTitle("Restaurer mot de passe");
		frmRestaurerMdp.setBounds(100, 100, 670, 459);
		frmRestaurerMdp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRestaurerMdp.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Configurer un nouveau mot de passe");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(168, 45, 301, 27);
		frmRestaurerMdp.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Entrez votre identifiant mail");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(145, 102, 233, 14);
		frmRestaurerMdp.getContentPane().add(lblNewLabel_1);

		mail = new JTextField();
		mail.setBounds(145, 127, 374, 27);
		frmRestaurerMdp.getContentPane().add(mail);
		mail.setColumns(10);

		JLabel lblNewLabel_1_1_1 = new JLabel("Entrez votre nouveau mot de passe");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(145, 165, 233, 14);
		frmRestaurerMdp.getContentPane().add(lblNewLabel_1_1_1);

		nouveaumdp = new JTextField();
		nouveaumdp.setColumns(10);
		nouveaumdp.setBounds(145, 190, 374, 27);
		frmRestaurerMdp.getContentPane().add(nouveaumdp);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("Confirmer votre nouveau mot de passe");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(145, 228, 250, 14);
		frmRestaurerMdp.getContentPane().add(lblNewLabel_1_1_1_1);

		cnmdp = new JTextField();
		cnmdp.setColumns(10);
		cnmdp.setBounds(145, 253, 374, 27);
		frmRestaurerMdp.getContentPane().add(cnmdp);

		JButton btnNewButton = new JButton("Mettre \u00E0 jour");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!Pattern.matches("^[a-zA-Z0-9]+[@]{1}+[a-zA-Z0-9]+[.]{1}+[a-zA-Z0-9]+$", mail.getText())) {
					JOptionPane.showMessageDialog(null, "E-mail invalide");
				}
				else {
					if(new CompteDAO().getIdentifiantBD(mail.getText()) != null) {
						if(checkField(mail.getText()) == false && checkField(nouveaumdp.getText())==false
								&& checkField(cnmdp.getText())==false){ // on v�rifie si les champs sont vides
							if(mail.getText().equals(new CompteDAO().getIdentifiantBD(mail.getText()).getIdentifiant())){
								if(nouveaumdp.getText().equals(cnmdp.getText())) {
									Compte compte = new Compte(new CompteDAO().getIdentifiantBD(mail.getText()).getIdCompte(), mail.getText(), nouveaumdp.getText());
									new CompteDAO().RestaurerCompte(compte);
									JOptionPane.showMessageDialog(null, "Nouveau mot de passe enregistr� avec succ�s");
									btnNewButton.setEnabled(false);
								}
								else {
									JOptionPane.showMessageDialog(null, "Mots de passe diff�rents");
								}
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Remplissez tous les champs !");
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "E-mail innexistant");
					}
				}

			}
		});
		btnNewButton.setBackground(new Color(219, 112, 147));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.setBounds(407, 317, 112, 23);
		frmRestaurerMdp.getContentPane().add(btnNewButton);

		JButton btnRetourLa = new JButton("Retour \u00E0 la page de connexion");
		btnRetourLa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connexion p = new Connexion();
				p.frmArmada.setVisible(true);
				frmRestaurerMdp.dispose();
			}
		});
		btnRetourLa.setBackground(new Color(147, 112, 219));
		btnRetourLa.setBounds(145, 317, 214, 23);
		frmRestaurerMdp.getContentPane().add(btnRetourLa);
	}

}
