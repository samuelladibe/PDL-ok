package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;

public class infosArmada {

	public JFrame frmInformationsArmada;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infosArmada window = new infosArmada();
					window.frmInformationsArmada.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public infosArmada() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInformationsArmada = new JFrame();
		frmInformationsArmada.setTitle("Informations Armada");
		frmInformationsArmada.setBounds(100, 100, 450, 300);
		frmInformationsArmada.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
