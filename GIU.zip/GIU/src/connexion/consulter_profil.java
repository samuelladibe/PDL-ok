package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class consulter_profil {

	public JFrame frmConsulterProfil;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					consulter_profil window = new consulter_profil();
					window.frmConsulterProfil.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public consulter_profil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmConsulterProfil = new JFrame();
		frmConsulterProfil.setTitle("Consulter profil");
		frmConsulterProfil.setResizable(false);
		frmConsulterProfil.setBounds(100, 100, 744, 567);
		frmConsulterProfil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmConsulterProfil.getContentPane().setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Retour");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				profil p = new profil();
				p.frmProfil.setVisible(true);
				frmConsulterProfil.dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setBounds(587, 44, 86, 23);
		frmConsulterProfil.getContentPane().add(btnNewButton_3);
	}

}
