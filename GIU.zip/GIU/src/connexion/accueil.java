package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class accueil {

	public JFrame frmAccueil;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					accueil window = new accueil();
					window.frmAccueil.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public accueil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frmAccueil = new JFrame();
		frmAccueil.getContentPane().setBackground(new Color(135, 206, 250));
		frmAccueil.setResizable(false);
		frmAccueil.setTitle("Accueil");
		frmAccueil.setBounds(100, 100, 540, 403);
		frmAccueil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAccueil.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Profil");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				profil p = new profil();
				p.frmProfil.setVisible(true);
				frmAccueil.dispose();
			}
		});
		btnNewButton.setBackground(new Color(205, 92, 92));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(10, 220, 150, 40);
		frmAccueil.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Infos sur l'armada");
		btnNewButton_1.setBackground(new Color(205, 92, 92));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				infosArmada p = new infosArmada();
				p.frmInformationsArmada.setVisible(true);
				frmAccueil.dispose();
			}
		});
		btnNewButton_1.setBounds(170, 289, 150, 40);
		frmAccueil.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Laissez-passer");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				laisser_passer p = new laisser_passer();
				p.frame.setVisible(true);
				frmAccueil.dispose();
			}
		});
		btnNewButton_2.setBackground(new Color(205, 92, 92));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_2.setBounds(329, 220, 150, 40);
		frmAccueil.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\wadjo\\Desktop\\Esigelec 1A\\PDL\\LOT 3\\logo.png"));
		lblNewLabel.setBounds(134, 40, 234, 198);
		frmAccueil.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_3 = new JButton("D\u00E9connexion");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connexion p = new Connexion();
				p.frmArmada.setVisible(true);
				frmAccueil.dispose();
			}
		});
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBounds(355, 40, 124, 23);
		frmAccueil.getContentPane().add(btnNewButton_3);
	}
}
