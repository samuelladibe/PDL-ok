package connexion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class modifier_profil {

	public JFrame frmModifierProfil;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					modifier_profil window = new modifier_profil();
					window.frmModifierProfil.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public modifier_profil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmModifierProfil = new JFrame();
		frmModifierProfil.setTitle("Modifier Profil");
		frmModifierProfil.setBounds(100, 100, 688, 474);
		frmModifierProfil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmModifierProfil.getContentPane().setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Retour");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				profil p = new profil();
				p.frmProfil.setVisible(true);
				frmModifierProfil.dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setBounds(513, 44, 86, 23);
		frmModifierProfil.getContentPane().add(btnNewButton_3);
	}

}
