package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Compte;
import model.inscription;

public class CompteDAO extends ConnectionDAO {
	/**
	 * Constructeur
	 */
	public  CompteDAO() {
		super();
	}
	
	/**
	 * M�thode permettant d'ajouter un compte dans la table Ccompte de la BDD
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * @param compte
	 * @return
	 */
	public int addCompte(Compte compte) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO compte (idcompte, identifiant, motdepasse) VALUES (COMPTE_SEQ.nextVal, ?, ?)");
			ps.setString(1, compte.getIdentifiant());
			ps.setString(2, compte.getMdp());
			
			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de compte existe d�j�. Ajout impossible !");
			else
				e.printStackTrace();
		}  finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * M�thode permettant de restaurer un compte en changeant son mot de passe
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * @param compte
	 * @return an integer
	 */
	public int RestaurerCompte(Compte compte) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE compte set motdepasse = ? WHERE idcompte = ?");
			ps.setString(1, compte.getMdp());
			ps.setInt(2, compte.getIdCompte());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * M�thode permettant de v�rifiant si l'identifiant entr� par l'utilisateur correspond � celui dans la BDD
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * @param identifiant
	 * @return
	 */
	public Compte getIdentifiantBD(String identifiant) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Compte returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM compte WHERE identifiant = ?");
			ps.setString(1, identifiant);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Compte(rs.getInt("idcompte"),
									       rs.getString("identifiant"),
									       rs.getString("motdepasse"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * M�thode permettant de v�rifiant si le mot de passe entr� par l'utilisateur correspond � celui dans la BDD
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * @param mdp
	 * @return
	 */
	public Compte getMdpBD(String mdp) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Compte returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM compte WHERE motdepasse = ?");
			ps.setString(1, mdp);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Compte(rs.getInt("idcompte"),
									       rs.getString("identifiant"),
									       rs.getString("motdepasse"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
}
