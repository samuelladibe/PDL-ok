package dao;
/**
 * Classe d'acc�s � la base de donn�es
 * @author Ladib� Samuel
 *@version 1.0
 */

public class ConnectionDAO {
		/**
		 * Parametres de connexion a la base de donnees oracle
		 * URL, LOGIN et PASS sont des constantes
		 */
		final static String URL   = "jdbc:oracle:thin:@oracle.esigelec.fr:1521:orcl";
		final static String LOGIN = "C##_G2_G1_APP";   // nom d'utilisateur
		final static String PASS  = "APP_2_1";   // mot de passe acc�s � la base de donn�es
		
		/**
		 * Constructor
		 * 
		 */
		public ConnectionDAO() {
			// chargement du pilote de bases de donnees
			try {
				Class.forName("oracle.jdbc.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.err.println("Impossible de charger le pilote de BDD, ne pas oublier d'importer le fichier .jar dans le projet");
			}
		}
	}
