package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.Vehicule;
import model.inscription;

public class LaisserPasserDAO extends ConnectionDAO{
	/**
	 * Constructeur
	 * 
	 * 
	 */
	public  LaisserPasserDAO() {
		super();
	}

	/**
	 * m�thode permettant de verifier si un champ est vide
	 * @param field
	 * @return
	 */
	private boolean checkField(String field){
		if(!field.isEmpty()){ 
			return false;
		}else{
			return true;
		}
	}
	
	public int addVehicule(Vehicule vehicule) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO vehicule (idvehicule, modelvehicule, marque, longueur, largeur) VALUES (VEHICULE_SEQ.nextVal, ?, ?, ?,?)");
			ps.setString(1, vehicule.getModel());
			ps.setString(2, vehicule.getMarque());
			ps.setFloat(3, vehicule.getLongueur());
			ps.setFloat(4, vehicule.getLargeur());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de vehicule existe d�j�. Ajout impossible !");
			else
				e.printStackTrace();
		}  finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

}
